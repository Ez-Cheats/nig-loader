#pragma once

#include <d3d9.h>

#include "../imgui/imgui.h"
#include "../imgui/imgui_impl_dx9.h"
#include "../imgui/imgui_impl_win32.h"
#include <tchar.h>
#include <iostream>
#include <dinput.h>
#include <tchar.h>
#include <ctime>
#include <random>

#include <D3dx9tex.h>
#pragma comment(lib, "D3dx9")
namespace polygons
{

	int random_int(int min, int max);
	float distance(int x1, int y1, int x2, int y2);

	struct Point {
		ImVec2 point;
		float speedMod;
	};

	struct Points {
		Point point1;
		Point point2;
	};

	


	void dank_polys();
	void dank_polys2();
}


namespace gui
{


	static int width = 900;
	static int lenght = 600;

	inline HWND hwnd = nullptr;
	inline WNDCLASSEX wc = {};

	static LPDIRECT3D9              g_pD3D = NULL;
	static LPDIRECT3DDEVICE9        g_pd3dDevice = NULL;
	static D3DPRESENT_PARAMETERS    g_d3dpp = {};

	inline bool exit = true;
	bool CreateHwndWindow();
	void DestroyHwndWindow();

	bool CreateDeviceD3D();
	void ResetDevice();
	void CleanupDeviceD3D();

	void CreateImgui();
	void DestroyImgui();
	void Render();
	void bRender();
	void eRender();
}

namespace uiFont
{
	inline ImFont* Font4;
	inline ImFont* Font5;
}

namespace ui
{
	inline LPD3DXSPRITE Spimg = NULL;
	inline LPDIRECT3DTEXTURE9 img = NULL;
	void Polygons();
	bool LoggingScreen();
	void mainUi();
	bool LoadTextureFromFile(const char* filename, PDIRECT3DTEXTURE9* out_texture, int* out_width, int* out_height);
	bool DrawImage(int* x, int* y, LPDIRECT3DTEXTURE9* out_texture, LPD3DXSPRITE sprite);
	void RenderImage();
	void InitImage();
}